HR Loan:
=========================================================

Go to Setting / apps and search "HR / HR Loan" and Install

And, you are done with installation. Congratulations!
